﻿using System.Windows;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : Window
    {
        public $safeitemname$()
        {
            Resources.Add("services", Startup.Services);
            InitializeComponent();
        }
    }
}
